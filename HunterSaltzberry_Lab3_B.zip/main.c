// pseudocode

// import math for e and exp()
// declare floats for choice, engine, coffee, and soup
// declare floats for finalTemp, envTemp, tempDif, minutes, coolingConstant
// float e = exp(1)
// make a while loop so that we can go back if no valid selection is picked
// prompt user to input engine, coffee, or soup
// scan for input
// if / else branches that will set values to my vairables
// implement while loop ??
    // -10 minute iterations
    // print statements

#include <stdio.h>
#include <math.h>

int main()
{
    int choice, minutes;
    float finalTemp, envTemp, tempDif, coolingConstant;
    // float e = exp(1); <-- I no longer need this because exp(-kt) works too
    
    
    while(1){ // while loop in order to reask prompt in the case of invalid input
        printf("Select 1 for \"engine\", 2 for \"coffee\", or 3 for \"soup\" to discover their temperatures after certain times: ");
        // prompts user for their input
        
        if (scanf("%d", &choice) != 1 || (choice != 1 && choice != 2 && choice != 3)) { // detects for invalid input
            printf("Invalid input! Please select a valid option.\n");
            while (getchar() != '\n');  // I had to look this part up because invalid inputs were causing an infinite loop
            // my understanding is that it takes away some sort of input buffer that causes an infinite loop
        } 
        else { 
            break; // moves forward with valid input
        }
    }
    
    if (choice == 1){
        tempDif = 190 - 60, envTemp = 60, coolingConstant = 0.0341; // setting vairables for each case
    } 
    else if (choice == 2){
        tempDif = 200 - 70, envTemp = 70, coolingConstant = 0.4856;
    } 
    else if (choice == 3){ // I could technically just use else here instead of else if but better safe than sorry
        tempDif = 210 - 65, envTemp = 65, coolingConstant = 0.05;
    }
    
    printf("Enter the time (in minutes) to calculate temperature: "); // prompts user for time variable
    scanf("%d", &minutes);
    
    // the while loop requirement is a little confusing to me, but from what I understand,
    // I am supposed to take the time and iterate it by -10 due to the times given in the prompt
    
    
    while (minutes > 0){
        finalTemp = envTemp + (tempDif * exp( -coolingConstant * minutes));
        printf("The temperature after %d minutes is %.2f degrees Farenheit\n", minutes, finalTemp);
        minutes -= 10;
    }
    
    return 0;
}
