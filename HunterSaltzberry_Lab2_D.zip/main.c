// pseudocode

// define string (I will use size 100)
// prompt user for sandwich
// scan for input
// print ____ is a great sandwich

// pseudocode did not go as planned

#include <stdio.h>
#include <string.h> // had to include string library so that I could use strchr

int main()
{
    char sandwich[100]; // defines sandwich as a 99 character string (null is 100)
    
    printf("What is your favorite sandwich? "); // prompts user for their favorite sandwich
    fgets(sandwich, sizeof(sandwich), stdin); // gets input for favorite sandwich
    
    // had to learn how to use fgets instead of scanf because scanf ends at a whitespace (a space between words)
    // as far as I understand, fgets needs the string variable,
    // sizeof in order to not overflow the array, and stdin so that my input is read
    // fgets adds a \n at the end of my string so now I need to figure out how to remove it 
    
    char *n = strchr(sandwich, '\n'); // defines n as the newline in my string, and the * makes it so that the memory can be modified
    if (n){
        *n = '\0'; // makes the newline a null value
    } 
    
    printf("%s is a great sandwich!", sandwich); // final print statement
}

