// pseudocode
// define main funcion
// define variables
    // hourly rate (which is set)
    // number of weeks worked
    // number of hours worked each week
    // annual salary
    // monthly salary
// scanf for weeks and hours worked
    // hourly rate * hours * weeks
// calculate salary
// print salary

#include <stdio.h> //includes scan and print functions

int main() // main function
{
    int hours, weeks;   //defining the variables that we need to use for this lab
    float rate = 15.75;
    float annual, monthly;
    
    printf("enter the number of hours worked per week: "); // print statements to prompt user for information
    scanf("%d", &hours);    // scan statements to input information
    printf("enter the number of weeks worked this year: ");
    scanf("%d", &weeks);
    
    annual = rate * hours * weeks; // calculates annual salary
    
    monthly = annual / 12; // calculates monthly salary based on the annual salary
    
    printf("Your annual salary is $%.2f which makes your monthly salary $%.2f.", annual, monthly); // final print statement
}
