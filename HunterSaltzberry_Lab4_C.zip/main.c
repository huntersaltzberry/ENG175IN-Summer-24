// pseudocode

// sumnation lab actually seems pretty cool and interesting

// int x 
// int sum = 0
// for x = 1, x <= 10, x++
    // sum += (3* x) - 7
// print sum

#include <stdio.h>

int main()
{
    int x; // initializing variables
    int sum = 0;
    
    for (x = 1; x <= 10; x++){ // for loop that increments for each x 1 through 10
        sum += (3 * x) - 7; // basically does a sumnation function
    }
    
    printf("The sum is %d.", sum); // prints the sum, and 95 is correct

    return 0;
}