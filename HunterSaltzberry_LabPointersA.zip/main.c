/*
Get two double inputs from the user. Then create two pointer variables which store the
memory address of the previous two pointers. Use these pointers to multiply the double
inputs by a factor of 10. Print the new value of the input variables as well as their memory
location and the values stored in the pointer variables.

pseudocode

double var1, var2, *p1, *p2
prompt user for var1 and var2
assign p1 and p2 as the pointers for var1 and var2
*p1 *= 10
*p2 *= 10
print statements that tell us the new values of var1 and var2 and the memory locations and the values stored

*/

#include <stdio.h>

int main()
{
    
    double var1, var2; // declaring our variables and pointers
    double *p1, *p2;

    printf("Enter the first number: "); // prompts user for numbers
    scanf("%lf", &var1);
    printf("Enter the second number: ");
    scanf("%lf", &var2);

    p1 = &var1; // creating the pointers to store memory addresses
    p2 = &var2;

    *p1 *= 10; // multiplying our vars by using the pointers
    *p2 *= 10;

    // print statements that were requested in the prompt
    printf("New values of var1 and var2: %.2f\n and %.2f\n", var1, var2);
    printf("Memory addresses of var1 and var2: %p\n and %p\n", (void*)p1, (void*)p2); // I did some research and it said that we use void in order to ensure that
    printf("Value pointed to by p1 and p2: %.2f\n and %.2f\n", *p1, *p2);
    
    return 0;
}