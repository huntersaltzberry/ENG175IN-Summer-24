/*
Imagine that you are a vacation sell agent and you are trying to find customers. To do this you have
obtained a text file named Lab9b.txt, which contains information about possible customers. Each line of the
file contains the following information in order:
FirstName, LastName, Age, household Income, Married, and State
Use your C skills to read the file and store this data in an array of structures (name this structure person).
Then determine who are your best possible customers using the constraints:
1. The customer must have an income of 60K if they are single or 100K if they are married.
2. If the customer lives in California (CA), the income amount is 80K for single and 150K for married.
3. Consider customers over the age of 21 only.
Print the following message for all the customers that meet the above guideline.
Print(“Reach out to FirstName Last Name from State and Age”) where FirstName, LastName, and Age are
information from the person structure.

pseudocode:
first define the struct

struct customer {
    char firstName[25]
    char lastName[25]
    int age
    int income
    bool married
    char state[5]
}
We need bool.h 

    struct customer person[10]  --> since there are 10 people
    
    open the file
    FILE *file = fopen("Lab9C.txt", "r")
    if (file == NULL) {
        printf("Error opening file\n")
        return 1
    }
    
    "C:\Users\hunte\Downloads\Lab9C.txt" --> going to use this path to test from my compiler
    figured it out without it nevermind

    read the info
    for (int i = 0; i < 10; i++) {
        fscanf(file, "%s %s %d %d %c %s", 
               person[i].firstName, --> writing the code in new lines because the readibility was horrible
               person[i].lastName, 
               &person[i].age, 
               &person[i].income, 
               &person[i].married,
               person[i].state)
        person[i].married = (person[i].married == 'Y') --> sets married to true if married has a Y
    }
    
    close the file
    fclose(file)
    
    for (int i = 0; i < 10; i++) { --> loop check each candidate (all 10)
        if (person[i].age <= 21) continue --> skips over anyone who is not 21 yet
        
        now we check for qualifications
        bool qualifies = false
        
        if (strcmp(person[i].state, "CA") == 0) { --> returning 0 because person[i].state is equal to CA
            if (person[i].married && person[i].income >= 150000){
                qualifies = true   --> checks for cali standards while the
            }                          else checks for other standards
            if (!person[i].married && person[i].income >= 80000){
                qualifies = true
            }
        } 
        else {
            if (person[i].married && person[i].income >= 100000){
                qualifies = true
            }
            if (!person[i].married && person[i].income >= 60000){
                qualifies = true
            }
        }
    
        print info
        if(qualifies) --> uses the boolean to check if they qualify
        Print("Reach out to FirstName LastName from State and Age", person[i].firstName, person[i].lastName, 
        person[i].state, person[i].age)person

*/

#include <stdio.h>
#include <string.h> // for string functions, specifically strcmp
#include <stdbool.h>

struct customer {
    char firstName[25]; // struct to store all potential customer info from the file
    char lastName[25];
    int age;
    int income;
    bool married;
    char state[5];
};

int main()
{
    struct customer person[10]; // declaring the struct in main using the number of candidates
    
    FILE *file = fopen("Lab9C.txt", "r"); // to open the file
    if (file == NULL) {
        printf("Error opening file\n"); // aborts program if file can't open
        return 1;
    }
    
    for (int i = 0; i < 10; i++) { // reads the info from the file
        char marriedChar;
        fscanf(file, "%s %s %d %d %c %s", 
               person[i].firstName, // making new lines for readability
               person[i].lastName, 
               &person[i].age, 
               &person[i].income, 
               &marriedChar, // had a hard time implementing solution here, this is what i came up with
               person[i].state);
        person[i].married = (marriedChar == 'Y'); // sets married value to true if the file says they're married
    }
    
    fclose(file); // closes the file bc we're done with it
    
    for (int i = 0; i < 10; i++){ // loops through all 10 candidates
        if (person[i].age <= 21) continue; // continue to kill that iteration of the loop if candidate is < 21 
        
        bool qualifies = false; // setting up qualification boolean
        
        if (strcmp(person[i].state, "CA") == 0) { // strcmp returns 0 if two values are equal, this isn't a boolean. I was confused at first
            if (person[i].married && person[i].income >= 150000){ // checks if qualifications are met and sets bool to true if they are
                qualifies = true; // married in cali
            }
            if (!person[i].married && person[i].income >= 80000){ // cali has different qualifications
                qualifies = true; // not married cali
            }
        } 
        else {
            if (person[i].married && person[i].income >= 100000){
                qualifies = true; // married
            }
            if (!person[i].married && person[i].income >= 60000){
                qualifies = true; // not married
            }
        }
    
        if(qualifies){ // prints the info using the boolean to check for qualification
        printf("Reach out to %s %s from %s who is %d\n", person[i].firstName, person[i].lastName, 
        person[i].state, person[i].age);
        }
    }
    
    return 0;
} // pretty lengthy lab, but fun challenge