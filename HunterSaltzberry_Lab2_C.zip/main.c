// pseudocode

// Define 3 chars
// Prompt user for first (captitalized) letter
// Scan function to input character
    // If function to ensure that the letter is captitalized
// Prompt user for second letter
// Scan function to input character
// Prompt user for third letter
// Scan function to input character
// Print out resulting three letter word


#include <stdio.h>

int main()
{
    char first, second, third; // initializing variables
    
    printf("input the first letter: "); // print statement to prompt for first character
    scanf(" %c", &first); // scan to input first character
    
    if (first >= 'a' && first <= 'z'){
        first = first - 'a' + 'A';
    }
    
    printf("input the second letter: "); // print statement to prompt for seocnd character
    scanf(" %c", &second); // scan to input second character
    
    // Note: no if statement for second or third character because they are not case-sensitive
    
    printf("input the third letter: "); // print statement to prompt for third character
    scanf(" %c", &third); // scan to input third character
    
    printf("Your three letter word is %c%c%c!", first, second, third); // final print statement to show resulting word
    
    return 0;
}
