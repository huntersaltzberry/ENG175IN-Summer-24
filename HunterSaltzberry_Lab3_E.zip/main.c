// pseudocode

// same kind of program as earlier except now we use strings instead of 1 letter characters
// string[] operation
// prompt user for operation
    // 'plus' 'sub' 'mult' 'div'
// check to see if user entered a valid input
// prompt user for two numbers
// use switch command for calculator cases
// case(plus)
    // add num1 and num2
// same for sub and mult
// for div, check for dividing by zero then procede
// print result


#include <stdio.h>
#include <string.h> // always a good idea to include string library when working with strings

int main()
{
    char opString[20]; // the reason I picked a string size of 20 is to mitigate the risk of inputs causing stack smashing
    double num1, num2, result;
    int opValue;

    while(1){
        printf("Select an operation for the calculator to perform. \n"); // prompts user for their operation
        printf("('plus' for +, 'sub' for -, 'mult' for *, and 'div' for /): ");
        scanf("%s", opString); // takes users input
        
        if (strcmp(opString, "plus") == 0){ // this is a series of if/else statements that help determine if the input was valid
            opValue = 1;                  // then it takes a valid input and ties it to an integer
            break;  // break statement breaks the loop if valid operation is selected
        } 
        else if (strcmp(opString, "sub") == 0){
            opValue = 2;
            break;
        } 
        else if (strcmp(opString, "mult") == 0){
            opValue = 3;
            break;
        } 
        else if (strcmp(opString, "div") == 0){
            opValue = 4;
            break;
        }
        else{ // I'm using a while loop so that the code doesn't just end upon invalid operation
            printf("Please enter a valid operation! \n\n");
        }
    }
    
    printf("Enter the two numbers you would like to operate with: "); // prompts user for their two numbers
    scanf("%lf %lf", &num1, &num2);
    
    switch (opValue){
        case 1: // case for adding
            result = num1 + num2;
            printf("%lf + %lf = %lf", num1, num2, result);
            break;
        case 2: // case for subtracting
            result = num1 - num2;
            printf("%lf - %lf = %lf", num1, num2, result);
            break;
        case 3: // case for multiplying
            result = num1 * num2;
            printf("%lf * %lf = %lf", num1, num2, result);
            break;
        case 4: // case for dividing
            if (num2 == 0){ // you can't divide by zero
                printf("Division by zero. Undefined result.");
                break;
            }
            else{
                result = num1 / num2;
                printf("%lf / %lf = %lf", num1, num2, result);
                break;
            }
        
    }

    return 0;
}
