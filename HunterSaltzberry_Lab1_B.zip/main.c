//Lab1_B -- Length and Width (of a rectangle)
//Hunter Saltzberry -- ENG175IN

#include <stdio.h>

int main()
{
    float length, width, area;
    
    printf("Input the length of the rectangle: ");
    scanf("%f", &length);
    
    printf("Input the width of the rectangle: ");
    scanf("%f", &width);
    
    area = length * width;
    
    printf("A rectangle with length %.2f and width %.2f has an area of %.2f.", length, width, area);
    

    return 0;
}
