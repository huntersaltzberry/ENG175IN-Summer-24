/*
Staring with the equation 𝑦 = 𝑥2 − 4 determine the zeros of the equation using the quadratic formula.

Code 1: Write a code to put a, b, and c into a file

a = 1
b = 0
c = -4

pseudocode:

open the file to write in it
FILE *file = fopen("coefficients.txt", "w") --> w to write in the file
    if (file == NULL) { --> use error message condition when working with files always
        printf("Error opening file!\n")
        return 1;
    }
    
write coefficients into the file
fprintf("%d, %d, %d", 1, 0, -4)--> like scanf but for files
close the file
fclose(file)

return 0
*/

#include <stdio.h>

int main()
{
    
    FILE *file = fopen("coefficients.txt", "w"); // opens file to write in it using w to write in the file
    if (file == NULL) { // if file can't open abort program
        printf("Error opening file!\n");
        return 1;
    }
    
    fprintf(file, "%d, %d, %d", 1, 0, -4); // writing the coefficients into the file

    fclose(file); // closes the file 
    
    return 0;
}
