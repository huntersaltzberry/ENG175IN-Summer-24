// pseudocode

// int number, digit
// int sum = 0
// prompt user for number
// while (number > 0)
    // digit = number % 10 to grab the remainder (last digit)
    // sum += digit
    // number /= 10 to take the last digit off of the number
// print the sum

#include <stdio.h>

int main()
{
    int number, digit; // initializing variables
    int sum = 0;
    
    printf("Enter a number to see the sum of its digits: "); // prompting user for number
    scanf("%d", &number);
    
    while (number > 0){ // while loop to get each digit
        digit = number % 10; // takes the last digit of the number and isolates it as digit
        sum += digit; // adds digit to the sum
        number /= 10; // takes the last digit off the number to get ready to take the next one
    }
    
    printf("The sum of the digits of your number is %d", sum); // prints the sum

    return 0;
}
