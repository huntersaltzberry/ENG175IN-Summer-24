/*
Have your neighbor write a 4-word sentence
Code 2: read the file and print it to the computer.

pseudocode:

open file
FILE *file = fopen("sentence.txt", "r")
    if (file == NULL) {
        printf("Error opening file!\n")
        return 1
    }
    
read and print sentence from file
char sentence[100]; --> initializes array where the sentence will be assigned to
    if (fgets(sentence, 100, file) != NULL) {
        printf("The sentence from the file is: %s", sentence)
    } else {
        printf("Error reading file!\n")
        return 1
    }

close file
fclose(file)

*/
#include <stdio.h>

int main()
{
    FILE *file = fopen("sentence.txt", "r"); // opens the file in read mode
        if (file == NULL) {
            printf("Error opening file!\n"); // aborts program if file can't be opened
            return 1;
        }
        
    char sentence[100]; // declaring the array where the sentence will be assigned to so we can print it
        if (fgets(sentence, 100, file) != NULL) { // if the file is opened and read then we continue
            printf("The sentence from the file is: %s", sentence); // prints the sentence from the file
        } else {
            printf("Error reading file!\n"); // aborts program if file can't be read
            return 1;
        }
    
    fclose(file); // closes the file
    
    return 0;
}
