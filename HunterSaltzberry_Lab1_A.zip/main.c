//Lab1_A - Hello World
// Hunter Saltzberry ENG175IN

#include <stdio.h>

int main()
{
    printf("Hello World\n");
    printf("May, 30, 2024\n");
    printf("Hunter Saltzberry");

    return 0;
}

