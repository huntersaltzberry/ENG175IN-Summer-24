/*
Look up your dream car on the internet. Then write a program using struct to store the car brand, the
year it was made and the price

struct dreamCar{
    char brand[50]
    int yearMade
    double price
}

main
    struct dreamCar hunter
    
    strcpy(hunter.brand, "Porsche 911 977.2 Turbo") --> strcpy for string assignments
    hunter.yearMade = 2009
    hunter.price = 60000
    
    printf("My dream car is the %s.\n It was produced in %d, and goes for about $%.2lf", hunter.brand, hunter.yearMade, hunter.price)
    
}
*/
#include <stdio.h>
#include <string.h> // including for strcpy

struct dreamCar{ // dream car struct
    char brand[50];
    int yearMade;
    double price;
};

int main()
{
    struct dreamCar hunter; // adding myself to the struct to put my info
    
    strcpy(hunter.brand, "Porsche 911 977.2 Turbo"); // assigning my personal values
    hunter.yearMade = 2009;
    hunter.price = 60000;
    
    printf("My dream car is the %s.\nIt was produced in %d, and goes for about $%.2lf.", hunter.brand, hunter.yearMade, hunter.price);
    // final print statement
    
    return 0;
}
