// pseudocode

// I have a little bit of experience with for loops in c, but I'm not sure if we've done this in class
// (we are actually doing it in class as I'm writing the code)

// int rolls, dice1, dice2, sum
// print how many times do you want to roll the dice
// scan for rolls
// print table with results

// did some reading on rand() in c
// it seems that using rand() will produce the same numbers everytime you run the code
// using srand(time) will make the seed of the random number pool be pulled from your systems time
// this makes the dice rolls truly random every time you run the code, so I will be doing this

#include <stdio.h>
#include <stdlib.h> // including standard library so that I can use the random functions
#include <time.h> // including time so that I can use srand(time)

int main()
{
    srand(time(0)); // sets the random number seed with relation to the system's time
    
    int rolls, dice1, dice2, sum;
    int i;
    
    printf("How many times would you like to roll the dice? "); // prompts user
    scanf("%d", &rolls);
    
    printf("\n"); // added for better readability of output
    
    for (i = 1; i <= rolls; i++){ // for loop header
        dice1 = (rand() % 6) + 1; // we have to add a plus 1 here because rand() % 6 gives us 0-5
        dice2 = (rand() % 6) + 1;
        sum = dice1 + dice2;
        printf("Roll: %d     Dice 1: %d     Dice 2: %d     Value of Roll: %d\n", i, dice1, dice2, sum); // prints 1 row of table
    }
    
    return 0;
}
