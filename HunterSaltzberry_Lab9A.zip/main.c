/*
Write a C program using struct to store a student’s name, student number, and GPA. Use scanf to input
the information and print out the results in one line. You may choose to write a flow chart or pseudo-
code

Did a fair bit of research on structs prior to pseudocode

pseudocode:

struct Student {
    char name[50]
    int studentNum
    double GPA
}

main
{
    struct Student student
    
    prompt user for students name number and gpa using printf and scanf statements
    
    print in one line
    printf("Student Name: %s, Student Number: %d, Student GPA: %lf", student.name, student.studentNum, student.GPA)
    
    return 0
}
    
*/

#include <stdio.h>

struct Student { // defining the struct outside of main
    char name[50]; // declaring struct's variables
    int studentNum;
    double GPA;
}; // semicolon on bracket

int main()
{
    struct Student student; // declaring student using the struct
    
    printf("Enter student's name: "); // prompting user for information on student
    scanf("%s", student.name);
    printf("Enter student's ID#: ");
    scanf("%d", &student.studentNum);
    printf("Enter student's GPA: ");
    scanf("%lf", &student.GPA);
    
    printf("Student Name: %s, Student Number: %d, Student GPA: %.2lf", student.name, student.studentNum, student.GPA);
    // printing the info in one line using calls to the struct
    
    return 0;
}