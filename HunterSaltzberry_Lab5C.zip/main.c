/*
Program to add two 3x3 matrices (Adding Functionality for the rest of the criteria)

int matrixa[3][3]. matrixb[3][3], sum[3][3]

input for the first matrix (i is rows and j is columns)
for (int i = 0, i < 3, i++)
    for (int j = 0, j < 3, j++)
        scanf("%d", matrixa[i][j])

copy same thing for second matrix using b


*adding the matrices*
printf("The sum of the matrices is: \n")
use a nested for loop to iterate through all matrix coordinatets
for (int i = 0, i < 3, i++)
    for (int j = 0, j < 3, j++)
        sum[i][j] = matrixa[i][j] + matrixb[i][j]
        printf(sum[][]\t)   i learned about \t which enters a tab which is good for making columns
    printf new line (to make the next row)

*** upon following this pseudocode i realized that i needed to add a lot for user friendliness ***
added print statements and adding for loops to print out the addends before printing the sum
this is more difficult than it seemed but hopefully I can just copy this code for the subtraction

*adding a nested for loop that will do subtraction*

pseudocode for multiplication:
I'm pretty well versed in linear algebra thankfully, so hopefully that helps with the next three tasks
This seems rather hard considering that I need to multiply rows by columns
I am going to do some research
source of my research: "https://www.youtube.com/watch?v=jzdQqoG1tZs&ab_channel=NesoAcademy"
(not trying to plagiarize, just trying to learn)
it looks like we use a third nested for loop in order to keep track of a columns and b rows at the same time
without iterating through both rows and both columns simultaneously
it'll look something like this:

int product[3][3]
for (i = 0; i < 3; i++){
    for (j = 0; j < 3; j++){
        for (k = 0; k < 3; k++){
            sum += matrix_a[i][k] * matrix_b[k][j] --> this will add the product of each of a's rows with b's columns 
        }
        product[i][j] = sum
        sum = 0
    }
}

*sum of right diagonals*
i think that this is referring to adding [0][0], [1][1], and [2][2] of matrices a and b
i looked up what the right diagonal is and that's what I found, although there was some conflicting information
if i did the wrong thing, i am more than willing to recitfy it

int diag_sum = 0
for (i = 0; i < 3; i++)
    diag_sum += matrix_a[i][i] + matrix_b[i][i];
printf("The sum of the right diagonals is %d", diag_sum); --> this should be it

*transposing a matrix*
no research needed we are just flipping over the right diagonal
this means we just need to swap i and j values of a matrix
it says to use a given matrix but I'll just use matrix a

int tran[3][3]
for (i = 0; i < 3; i++){
    for (j = 0; j < 3; j++){
        tran[j][i] = matrix_a[i][j];
        (we can't print here because it will print in the wrong order so now we gotta do a new for loop)
    }
}
for (i = 0; i < 3; i++){
    for (j = 0; j < 3; j++){
        printf("%d", tran[i][j]);
    }
    printf("\n");
}

that should be all. I wrote an entrire essay here. this took about 3 hours lol but I think I am a lot more profecient with arrays now
*/
#include <stdio.h>

int main()
{
    int matrix_a[3][3], matrix_b[3][3], sum[3][3];
    
    for (int i = 0; i < 3; i++){ // nested for loop that prompts user to input first matrix
        for (int j = 0; j < 3; j++){ // the reason that we use a nested for loop is because in C, matrices are essentially 2d arrays
            printf("Enter element [%d][%d] for matrix a: ", i + 1, j + 1);
            scanf("%d", &matrix_a[i][j]);
        }
    }
    
    for (int i = 0; i < 3; i++){ // nested for loop that prompts user to input second matrix
        for (int j = 0; j < 3; j++){
            printf("Enter element [%d][%d] for matrix b: ", i + 1, j + 1);
            scanf("%d", &matrix_b[i][j]);
        }
    }
    
    printf("Matrix A:\n"); // prints matrix a given the user input
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            printf("%d\t", matrix_a[i][j]);
        }
        printf("\n");
    }
    
    printf("Matrix B:\n"); // prints matrix b given the user input
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            printf("%d\t", matrix_b[i][j]);
        }
        printf("\n");
    }
    
    printf("The sum of the matrices is: \n");
    
    for (int i = 0; i < 3; i++){ // prints sum of the matrices using another nested for loop to go through the 2d array
        for (int j = 0; j < 3; j++){ // and use those values to get the sum
            sum[i][j] = matrix_a[i][j] + matrix_b[i][j];
            printf("%d\t", sum[i][j]);
        }
        printf("\n");
    }
    
    printf("Matrix A minus Matrix B is: \n");
    
    for (int i = 0; i < 3; i++){ // prints difference between a and b
        for (int j = 0; j < 3; j++){
            sum[i][j] = matrix_a[i][j] - matrix_b[i][j];
            printf("%d\t", sum[i][j]); // i'm continuing to use sum[i][j] because I just copied and modified the addition module
                                       // and i COULD change the variable name here, but it's not really necessary
        }
        printf("\n");
    }
    
    printf("Matrix B minus Matrix A is: \n");
    
    for (int i = 0; i < 3; i++){ // prints difference between b and a
        for (int j = 0; j < 3; j++){ // now that I think about it, it may have been easier if I just used -(a-b)
            sum[i][j] = matrix_b[i][j] - matrix_a[i][j];
            printf("%d\t", sum[i][j]);
        }
        printf("\n");
    }
    
    printf("Matrix A times Matrix B is: \n");
    
    int product[3][3]; // multiplies a and b. The video was very informative and now I understand how this works to a tee
    int mult_sum = 0; // i had to define a new variable because sum is an array earlier in the code
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            for (int k = 0; k < 3; k++){
                mult_sum += matrix_a[i][k] * matrix_b[k][j]; // iterates through rows of a and columns of b
            } // for instance, it will add [0][1] of a to [1][0] of b and so on
            product[i][j] = mult_sum; // sets sum to be the next entry of the matrix
            printf("%d\t", mult_sum); // prints each sum value
            mult_sum = 0; // resets sum value for next entry on matrix
        }
        printf("\n"); // new line to start a new row
    }
    
    int diag_sum = 0; // initializes diagonal sum variable
    for (int i = 0; i < 3; i++){ // for loop to move through 2d array
        diag_sum += matrix_a[i][i] + matrix_b[i][i]; // adds 0,0 1,1 and 2,2 of both arrays
    }
    printf("The sum of the right diagonals of Matrix A and Matrix B is: %d\n", diag_sum);
    
    int tran[3][3]; // declaring new matrix to assign transposed numbers there
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            tran[j][i] = matrix_a[i][j]; // assigns element of matrix a to the corresponding element of the transposition
        }
    }
    printf("Transposition of Matrix A: \n");
    for (int i = 0; i < 3; i++){ // nested for loop to print out the transposed matrix a
        for (int j = 0; j < 3; j++){
            printf("%d\t", tran[i][j]);
        }
        printf("\n");
    }

    return 0;
}
