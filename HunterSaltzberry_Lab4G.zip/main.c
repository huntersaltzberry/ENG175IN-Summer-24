/*
Write a program to play an automated Rock, Paper, Scissors game. Two players make one of three hand
signals at the same time. Hand signals represent a rock, a piece of paper, or a pair of scissors. Each
combination results in a win for one of the players. Rock crushes scissors, paper covers rock, and scissors
cut paper. A tie occurs if both players make the same signal. Have an input of players' names and how
many rounds they want to play. A random number generator of 0 (rock), 1 (paper), or 2 (scissors) to
represent the three signals.

pseudocode

we need the players names, how many rounds they want to play, and a score count

since we are using rng, we will seed the random number generator with the systems time.

prompt user(s) for names and how many rounds they want to play

use a for loop to iterate through each round. 
use 0-2 for choices and make if else statements that determine what beats what
keep track of scores

use final scores to make print statements saying who won
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    char player1[50], player2[50]; // initializes variables
    int rounds, score1, score2;
    
    srand(time(0)); // seeds a random number using system time
    
    printf("Enter the name of Player 1: "); // prompts user for info
    scanf("%s", player1);
    printf("Enter the name of Player 2: ");
    scanf("%s", player2);
    printf("Enter the number of rounds: ");
    scanf("%d", &rounds);
    
    for (int i = 1; i <= rounds; i++){
        int player1_choice = rand() % 3; // assigns each players choice of "rock" "paper" or "scissors"
        int player2_choice = rand() % 3;
        
        printf("Round %d: ", i);
        // 0 is rock, 1 is paper, 2 is scissors
        
        if (player1_choice == player2_choice){ // if/else that determines who won based on which choice was made
            printf("It's  a tie!\n");
        }
        else if ((player1_choice == 1 && player2_choice == 0) || (player1_choice == 2 && player2_choice == 1) || (player1_choice == 0 && player2_choice == 2)){
            printf("%s wins this round!\n", player1);
            score1++;
        }
        else{
            printf("%s wins this round!\n", player2);
            score2++;
        }
    }
    
    if (score1 > score2){ // final print statements saying who won
        printf("after %d rounds, %s has won with a score of %d to %d!", rounds, player1, score1, score2);
    }
    else if (score2 > score1){
        printf("after %d rounds, %s has won with a score of %d to %d!", rounds, player2, score2, score1);
    }
    else{
        printf("Both players have tied with a score of %d", score1);
    }
    
    return 0;
}
