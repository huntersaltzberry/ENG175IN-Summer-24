/*
Have your neighbor write a 4-word sentence 
Code 1: Write a code to put the sentence in a file
This has me assume the sentence is prewritten

pseudocode:

open file
FILE *file = fopen("sentence.txt", "w") in write mode
    if (file == NULL) {
        printf("Error opening file!\n")
        return 1;
    }
        
write sentence in file
fprintf(file, "I am coding tonight.")

close file
fclose(file)

*/
#include <stdio.h>

int main()
{
    
    FILE *file = fopen("sentence.txt", "w"); // opens the file to write in it
        if (file == NULL) { // failsafe if file doesn't open
            printf("Error opening file!\n");
            return 1;
        }
            
    fprintf(file, "I am coding tonight."); // writes sentence in file
    
    fclose(file); // closes file
    
    return 0;
}
