/*
Write a C program that has an array of ages print the array elements horizontally. The second and third
element of the array are then passed to a UDF that prints out the second and third element of the array.
Test case:
Use the ages: 2, 8, 4, 12
Output:
Print “ array: 2, 8, 4, 12 “
Prints: 8 and 4

pseudocode:

UDF to print 2 and 3

void twothree(int arr[])
{
    printf("\nPrints: %d and %d", arr[1], arr[2])
}
int main()
{
    int numAges
    
    prompt user for size of array
    printf("How many ages would you like to input? ")
    scanf("%d", &numAges)
    
    int array[numAges]
    
    for loop to input the ages
    printf("Enter the age values: \n")
    for (int i = 0; i < numAges; i++)
        printf("Enter age number %d: ", i + 1)
        scanf("%d", &array[i])
        
    for loop to print array
    printf("array: ")
    for (i = 0; i < numAges; i++)
        printf("%d, ", array[i])
        
    call for UDF
    twothree(array) --> don't need brackets when calling function with array
    
    return 0
}

*/
#include <stdio.h>

void twothree(int arr[]) // UDF for printing the second and third elements of the array
{
    printf("\nPrints: %d and %d", arr[1], arr[2]);
    // new line here so that I don't have to add an addition line for printf in main
}

int main()
{
    int numAges; // declares variable for the number of elements
    
    printf("How many ages would you like to input? "); // prompts user for array size
    scanf("%d", &numAges);
    
    int array[numAges]; // declares the array using the number of ages
    
    printf("Enter the age values: \n"); // for loop to input array elements
    for (int i = 0; i < numAges; i++){
        printf("Enter age number %d: ", i + 1);
        scanf("%d", &array[i]);
    }

    printf("array: "); // for loop that prints array in the format used in the test case
    for (int i = 0; i < numAges - 1; i++){
        printf("%d, ", array[i]); // going to try to get rid of comma after last element
                                    // i can just cut the for loop by one and add an individual printf
    }
    printf("%d", array[numAges - 1]); // prints last element with no comma
    
    twothree(array); // calls UDF to print second and third elements
    
    return 0;
}
