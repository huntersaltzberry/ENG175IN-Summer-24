/*
Create a function which behave similar to the math.h pow() function. The function will take two
parameter of type double and return a double. Ge the input values from the user and create print
statement to show the result of your function.
Test Data:
Input = newPow(2,2)
Output = 2 ---> I think the test data is wrong, no?
                pow(2,2) from math library returns 4

pseudocode
double newPow(x, power)
    result = 1
    for (int i = 1; i <= power; i++)
        result *= x
    return result
        
int main()
    double x, power, result
    print(enter two numbers (x,y) to compute x^y)
    scan("%lf, %lf", &x, &power)
    
    result = newPow(x, power)
    
    print("%lf to the power of %lf is %lf", x, power, result)


*/
#include <stdio.h>

double newPow(double x, double power) // UDF for power function
{
    double result = 1; // I found that I had to declare variables in both functions
    for (int i = 1; i <= power; i++){ // I'm wondering if there's a more efficient way to do this
        result *= x;                    // potentially global variables but I don't think that applies here
    }
    // for loop to multiply x by itself as many times as the power value says
    // I might have been able to use resursion here but I'm not super comfortable trying that yet
    return result; // returns result
}

int main()
{
    double x, power, result; // I did some research and it turns out that I can use different variable names for each function
                            // declaring variables
    printf("Enter two numbers (x and y) to compute x to the power of y: "); // prompts user for input
    scanf("%lf %lf", &x, &power);
    
    result = newPow(x, power); // cals newPow function to calculate the power function
    
    printf("%lf to the power of %lf is %lf", x, power, result); // prints the result

    return 0;
}
