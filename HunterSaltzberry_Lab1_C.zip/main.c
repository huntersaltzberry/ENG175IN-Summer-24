//Lab1_B -- Length and Width (of a rectangle)
//Hunter Saltzberry -- ENG175IN

#include <stdio.h>
#include <math.h>

int main()
{
    float x, y, z, perimeter, area;
    
    printf("enter the length of the inner-rod (x): ");
    scanf("%f", &x);
    
    printf("enter the length of the shorter cross-piece (y): ");
    scanf("%f", &y);
    
    printf("enter the length of the longer cross-piece (z): ");
    scanf("%f", &z);
    
    perimeter = (2 * y) + (2 * z);
    
    area = x * (sqrt(pow(y, 2) - pow(x, 2)) + sqrt(pow(z, 2) - pow(x, 2)));
    
    printf("The perimeter of the kite is %.2f. \n", perimeter);
    printf("The area of the kite is %.2f. \n", area);
    
}

