#include "election.h" // includes the header I made which has all of my real includes

int main()
{ // this main will pretty much implement things from the election files. Not much to be done here
    Person voters[50];
    int numVoters;  // declaring the variables I will use
    Party party1, party2;
    Vote* voteList = NULL;

    printf("Welcome to the election system!\n");

    readFile(voters); // reading the file using the UDF
    
    numVoters = getNumVoters(); // getting random number of voters using UDF
    
    printf("Whatever you do, do not put the same first name and last name\n for more than one candidate! ");
    printf("You have to rewrite them all\n if you do, and it takes forever!!\n");
    
    createParties(&party1, &party2); // creating the parties using UDF
                                    // this will actually implement the other UDFs I made to change same names
    
    char input;
    do { // this is from instruction number 5. We have to input E to start the election
        printf("Enter 'E' to start elections: "); // do while loop is the best way to do this
        scanf(" %c", &input);
        if (input != 'E') {
            printf("You didn't enter E, try again.\n");
        }
    } while (input != 'E');

    startElections(voters, numVoters, &party1, &party2, &voteList); // the UDF that actually does the program
    
    printResults(voteList, &party1, &party2); // UDF for tallying and printing the results

    // line 31 and 33 are essentially the powerhouses of this whole program

    while (voteList != NULL) { // continues until it hits the last node which will point to null
        Vote* temp = voteList; // makes the temporary pointer
        voteList = voteList->next; // moves through the nodes
        free(temp); // frees allocated memory for current node
    }

    return 0;
}