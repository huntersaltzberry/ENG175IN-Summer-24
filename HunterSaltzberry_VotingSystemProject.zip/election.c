#include "election.h" // includes the header I made which has all of my real includes

void readFile(Person* people){
    
    FILE* file = fopen("people.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }
                         // opens the file, reads the info and puts it into the program
    for (int i = 0; i < 50; i++){
        if (fscanf(file, "%s %s %d %s %s", 
            people[i].firstName, 
            people[i].lastName, 
            &people[i].age,
            people[i].SSN, 
            people[i].phone) == 5) {
            strcpy(people[i].party, "NA");
        }
        else {
            break;  // exits the loop if it can't read a complete person
                    // but there shouldn't be any incpmplete info to my knowledge
        }
    }
    
    fclose(file); // closes the file
}
    
int getNumVoters(){
    
    int num;
    
    do {  // do while to check if the number is the one that was asked for in the project
        printf("Enter the number of people participating in the elections: ");
        scanf("%d", &num);
        if (num < 3 || num > 50){
            printf("Number must be between 3 and 50. Enter a new number. \n");
        }
    } while (num < 3 || num > 50);
    return num;
}

    
void newName(Person* candidate, const char* position, const char* partyName){  // this UDF and the three after are all related and
                                                                              // took FOREVER!!
    printf("There was a conflict, so now new names must be entered. Enter new name for the %s %s candidate:\n", partyName, position);
    printf("First Name: ");                                                 // if they end up not working i'm going to cry
    scanf("%s", candidate->firstName);
    printf("Last Name: ");
    scanf("%s", candidate->lastName);
}

void createParties(Party* party1, Party* party2){
    printf("Enter first political party name: ");
    scanf("%s", party1->name);
    
    printf("Enter first name of president candidate: ");
    scanf("%s", party1->president.firstName);
    printf("Enter last name of president candidate: ");
    scanf("%s", party1->president.lastName);
    printf("Enter age of president candidate: ");
    scanf("%d", &party1->president.age);
    
    printf("Enter first name of senator candidate: ");
    scanf("%s", party1->senator.firstName);
    printf("Enter last name of senator candidate: ");
    scanf("%s", party1->senator.lastName);
    printf("Enter age of senator candidate: ");
    scanf("%d", &party1->senator.age);
    
    printf("Enter first name of congress candidate: ");
    scanf("%s", party1->congress.firstName);
    printf("Enter last name of congress candidate: ");
    scanf("%s", party1->congress.lastName);
    printf("Enter age of congress candidate: ");
    scanf("%d", &party1->congress.age);

    printf("second political party name: ");
    scanf("%s", party2->name);

    printf("Enter first name of president candidate: ");
    scanf("%s", party2->president.firstName);
    printf("Enter last name of president candidate: ");
    scanf("%s", party2->president.lastName);
    printf("Enter age of president candidate: ");
    scanf("%d", &party2->president.age);
    
    printf("Enter first name of senator candidate: ");
    scanf("%s", party2->senator.firstName);
    printf("Enter last name of senator candidate: ");
    scanf("%s", party2->senator.lastName);
    printf("Enter age of senator candidate: ");
    scanf("%d", &party2->senator.age);
    
    printf("Enter first name of congress candidate: ");
    scanf("%s", party2->congress.firstName);
    printf("Enter last name of congress candidate: ");
    scanf("%s", party2->congress.lastName);
    printf("Enter age of congress candidate: ");
    scanf("%d", &party2->congress.age);
    
    while (checkNameConflicts(party1, party2)){ // if the names are the same, the user has to write new ones
        newName(&party1->president, "President", party1->name); // luckily I was able to do a lot of copy and paste for these functions
        newName(&party1->senator, "Senator", party1->name);   // because they are EXTREMELY redundant
        newName(&party1->congress, "Congress", party1->name);
        newName(&party2->president, "President", party2->name);
        newName(&party2->senator, "Senator", party2->name);
        newName(&party2->congress, "Congress", party2->name);
    }
}


int compareNames(Person* p1, Person* p2){ // this uses strcmp to make sure both first and last names are different
    return (strcmp(p1->firstName, p2->firstName) == 0 && 
            strcmp(p1->lastName, p2->lastName) == 0);
    }
    
    
int checkNameConflicts(Party* party1, Party* party2){ // my name functions might be extremely inefficient but I'm
                                                        // not sure how else i would do them
    int conflict = 0;

    if (compareNames(&party1->president, &party2->president) || // checks every possible case where party 1 and 2 have same names
        compareNames(&party1->president, &party2->senator) ||
        compareNames(&party1->president, &party2->congress) ||
        compareNames(&party1->senator, &party2->president) || // I found that this UDF is what really got me comfortable with coding
        compareNames(&party1->senator, &party2->senator) ||  // with the linked list
        compareNames(&party1->senator, &party2->congress) ||
        compareNames(&party1->congress, &party2->president) ||
        compareNames(&party1->congress, &party2->senator) ||
        compareNames(&party1->congress, &party2->congress)){
        printf("Error: Two candidates from different parties have the same name.\n");
        conflict = 1;
    }

    if (compareNames(&party1->president, &party1->senator) || // checks within party 1
        compareNames(&party1->president, &party1->congress) ||
        compareNames(&party1->senator, &party1->congress)){
        printf("Error: Two %s candidates have the same name.\n", party1->name);
        conflict = 1;
    }

    if (compareNames(&party2->president, &party2->senator) || // checks within party 2
        compareNames(&party2->president, &party2->congress) ||
        compareNames(&party2->senator, &party2->congress)){
        printf("Error: Two %s candidates have the same name.\n", party2->name);
        conflict = 1;
    }

    return conflict;
}

void startElections(Person* voters, int numVoters, Party* party1, Party* party2, Vote** voteList){
    // this will pretty much be the main functionality of my code
    
    srand(time(NULL));  // seeds the random number generator with systems time 

    for (int i = 0; i < numVoters; i++){ // this will randomly assign the party affiliation to every voter
        int affiliation = rand() % 3;
        switch(affiliation){          // this will determine votes unless they are NA then it will be random
            case 0:
                strcpy(voters[i].party, "NA");
                break;
            
            case 1:
                strcpy(voters[i].party, party1->name);
                break;
            
            case 2:
                strcpy(voters[i].party, party2->name);
                break;
        }

        Vote* newVote = (Vote*)malloc(sizeof(Vote)); // creates each vote using dynamic memory
        if (newVote == NULL){
            printf("Memory allocation failed\n");  // failsafe
            exit(1);
        }

        newVote->voter = voters[i]; // copies the info of the current voter from the array 
                                   // into the vote structure. I'm not sure I understand completely
                                   // but it essentially initializes the next parts which I understand a lot more clearly

        if (strcmp(voters[i].party, party1->name) == 0){ // this says who each voter will vote for based on their party
            sprintf(newVote->selectPresident, "%s %s", party1->president.firstName, party1->president.lastName);
            sprintf(newVote->selectSenator, "%s %s", party1->senator.firstName, party1->senator.lastName);
            sprintf(newVote->selectCongress, "%s %s", party1->congress.firstName, party1->congress.lastName);
        }
        else if (strcmp(voters[i].party, party2->name) == 0){
            sprintf(newVote->selectPresident, "%s %s", party2->president.firstName, party2->president.lastName);
            sprintf(newVote->selectSenator, "%s %s", party2->senator.firstName, party2->senator.lastName);
            sprintf(newVote->selectCongress, "%s %s", party2->congress.firstName, party2->congress.lastName);
        }
        else { // this chooses a random party if they're unaffiliated, then uses the same lines as above to assign votes
            Party* chosenParty; // we are using rand to get a 50/50 chance at picking either party and then assigning them after
            
            if (rand() % 2 == 0) { // for pres
                chosenParty = party1;
            } else {
                chosenParty = party2;
            }
            sprintf(newVote->selectPresident, "%s %s", chosenParty->president.firstName, chosenParty->president.lastName);
            
            if (rand() % 2 == 0) { // for senator
                chosenParty = party1;
            } else {
                chosenParty = party2;
            }
            sprintf(newVote->selectSenator, "%s %s", chosenParty->senator.firstName, chosenParty->senator.lastName);
            
            if (rand() % 2 == 0) { // for congress
                chosenParty = party1;
            } else {
                chosenParty = party2;
            }
            sprintf(newVote->selectCongress, "%s %s", chosenParty->congress.firstName, chosenParty->congress.lastName);
        }
        
        newVote->next = *voteList; // puts the vote at the beginning of the linked list
        *voteList = newVote;

    }
    // this part was very difficult but I learned a lot
    // I learned sprintf which i'm going to explain here mostly to help me remember
    // So it's essentially combining first name and last name which we are accessing through the nodes
    // then it is assigning this value to the selectPresident, Senator, etc.
    // essentially a better printf for strings
}

void printResults(Vote* voteList, Party* party1, Party* party2) { // this will print the results of the elections
    
    int presidentVotes1 = 0; // declaring all of my variables for the vote tally
    int presidentVotes2 = 0;
    int senatorVotes1 = 0;
    int senatorVotes2 = 0;
    int congressVotes1 = 0;
    int congressVotes2 = 0;
    
    Vote* current = voteList;
    while (current != NULL) {  // while loop to tally up all of the results from the last UDF
       
        if (strstr(current->selectPresident, party1->president.firstName) == 0){
            presidentVotes1++;
        } 
        else { // i was having a problem where all votes were going to party 2 and had no idea what was wrong
            presidentVotes2++;   // apparently using strstr instead of strcmp will fix it
        }                  // IT FIXED IT THE CODE WORKS!!!!!!!!!
        
        if (strstr(current->selectSenator, party1->senator.firstName) == 0){
            senatorVotes1++;
        }
        else {
            senatorVotes2++;
        }
        
        if (strstr(current->selectCongress, party1->congress.firstName) == 0){
            congressVotes1++;
        }
        else {
            congressVotes2++;
        }
        
        current = current->next; // moves through the nodes in the linked list
    }
    
    printf("The elections results are the following:\n\n"); // all of my output printfs are going to copy the prompt
    
    if (presidentVotes1 > presidentVotes2){ // if else to print the results!!
        printf("Presidential winner is %s %s from the %s.\n", 
               party1->president.firstName, party1->president.lastName, party1->name);
        printf("%s obtained %d votes to defeat %s %s.\n\n", 
               party1->president.lastName, presidentVotes1, 
               party2->president.firstName, party2->president.lastName);
    } else if (presidentVotes2 > presidentVotes1){
        printf("Presidential winner is %s %s from the %s.\n", 
               party2->president.firstName, party2->president.lastName, party2->name);
        printf("%s obtained %d votes to defeat %s %s.\n\n", 
               party2->president.lastName, presidentVotes2, 
               party1->president.firstName, party1->president.lastName);
    } else {
        printf("Presidential race ended in a draw. Both candidates received %d votes.\n\n", presidentVotes1);
    }
    
    if (senatorVotes1 > senatorVotes2){ // I was able to copy and paste these modules from the first one thankfully
        printf("Senate winner is %s %s from the %s.\n", 
               party1->senator.firstName, party1->senator.lastName, party1->name);
        printf("%s obtained %d votes to defeat %s %s.\n\n", 
               party1->senator.lastName, senatorVotes1, 
               party2->senator.firstName, party2->senator.lastName);
    } else if (senatorVotes2 > senatorVotes1){
        printf("Senate winner is %s %s from the %s.\n", 
               party2->senator.firstName, party2->senator.lastName, party2->name);
        printf("%s obtained %d votes to defeat %s %s.\n\n", 
               party2->senator.lastName, senatorVotes2, 
               party1->senator.firstName, party1->senator.lastName);
    } else {
        printf("Senate race ended in a draw. Both candidates received %d votes.\n\n", senatorVotes1);
    } 
    
    if (congressVotes1 > congressVotes2){
        printf("Congress winner is %s %s from the %s.\n", 
               party1->congress.firstName, party1->congress.lastName, party1->name);
        printf("%s obtained %d votes to defeat %s %s.\n", 
               party1->congress.lastName, congressVotes1, 
               party2->congress.firstName, party2->congress.lastName);
    } else if (congressVotes2 > congressVotes1){
        printf("Congress winner is %s %s from the %s.\n", 
               party2->congress.firstName, party2->congress.lastName, party2->name);
        printf("%s obtained %d votes to defeat %s %s.\n", 
               party2->congress.lastName, congressVotes2, 
               party1->congress.firstName, party1->congress.lastName);
    } else {
        printf("Congress race ended in a draw. Both candidates received %d votes.\n", congressVotes1);
    }
}

// finally can put this all into main!!!