// defines the header and makes sure it doesn't get accessed multiple times
#ifndef ELECTION_H
#define ELECTION_H

// libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// structs
typedef struct {
    char firstName[15];
    char lastName[15];
    int age;
    char SSN[15];
    char phone[15];
    char party[20];
} Person;

typedef struct {
    char name[15];
    Person president;
    Person senator;
    Person congress;
} Party;

typedef struct Vote {
    Person voter;
    char selectPresident[30];
    char selectSenator[30];
    char selectCongress[30];
    struct Vote* next;
} Vote;


// UDFs
void readFile(Person* people);
int getNumVoters();
void createParties(Party* party1, Party* party2);
void startElections(Person* voters, int numVoters, Party* party1, Party* party2, Vote** voteList);
void printResults(Vote* voteList, Party* party1, Party* party2);
int compareNames(Person* p1, Person* p2);
void newName(Person* candidate, const char* position, const char* partyName);
int checkNameConflicts(Party* party1, Party* party2);

// prevents multiple inclusions of the same header, works with ifndef
#endif