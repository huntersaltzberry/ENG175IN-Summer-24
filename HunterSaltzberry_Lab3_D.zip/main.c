// pseudocode

// char letter
// prompt user for letter

// if else
    // if letter is a or e or i or o or u, letter is a vowel
    // if letter is y, its sometimes a value
    // else its a consonant
    
// I think that's all I need to do??

#include <stdio.h>
#include <ctype.h> // ctype is basically a library of commands that checks if characters are letters, numbers, etc.

int main()
{
    char letter; // initializes my variable
    
    while(1){ // I used a while loop so that the program would not end if you don't pick a letter
        printf("Pick any letter from a-z! "); // prompts user for letter
        scanf(" %c", &letter);
        letter = tolower(letter); // changes letter to lowercase regardless of initial input
    
    
        if (isalpha(letter)){ // checks if letter is in fact a letter
            if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u'){ // branches that cover my cases
                printf("Your letter is a vowel.");
            }
            else if (letter == 'y'){
                printf("Y is sometimes a vowel, but not always.");
            }
            else{
                printf("Your letter is a consonant");
            }
            break; // ends program if a letter is selected
        }
        else{
            printf("This is not a letter.\n"); // runs if character is not a letter
        }
    }

    return 0;
}
