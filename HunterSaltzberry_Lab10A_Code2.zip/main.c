/*
Staring with the equation 𝑦 = 𝑥2 − 4 determine the zeros of the equation using the quadratic formula.

Code 2: read the file and perform the calculation 𝑥 = −𝑏∓√𝑏2−4𝑎𝑐
2𝑏 .

pseudocode

I already attatched the file with the coefficients written inline

oprn the file
FILE *file = fopen("coefficients.txt", "r")
    if (file == NULL) {
        printf("Error opening file!\n")
        return 1;
    }
    
read the file and set a b and c to ints
int a, b, c
fscanf(file, "%d %d %d", &a, &b, &c)
   
close the file 
fclose(file)

double zero1, zero2

gonna include math.h

zero1 = (-b + sqrt((b*b) - (4 * a * c))) / (2 * a)

zero2 = (-b - sqrt((b*b) - (4 * a * c))) / (2 * a)

print the zeros
printf("The zeros of y = x^2 -4 are x = %.2lf and x = %.2lf", zero1, zero2)
*/

#include <stdio.h>
#include <math.h>

int main()
{
    FILE *file = fopen("coefficients.txt", "r"); // opens and reads the file
        if (file == NULL) { // aborts program if file can't open
            printf("Error opening file!\n");
            return 1;
        }
        
    double a, b, c; // setting these to doubles so that my equations work
    fscanf(file, "%lf, %lf, %lf", &a, &b, &c); // sets values to a, b, and c using the info read from the file
       // didn't have commas here and it took a while to figure out what was wrong with the code
       
    fclose(file); // closes the file
    
    double zero1, zero2; // declaring ints for zeros
    
    zero1 = (-b + sqrt((b*b) - (4.0 * a * c))) / (2.0 * a); // using quadratic equation to calculate zeros
    zero2 = (-b - sqrt((b*b) - (4.0 * a * c))) / (2.0 * a);
    
    printf("The zeros of y = x^2 -4 are x = %.2lf and x = %.2lf\n", zero1, zero2); // prints the results
    return 0;
}




