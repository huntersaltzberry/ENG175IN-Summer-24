/*
Write a program to find the quotient and remainder after dividing two numbers.
• Call a UDF to find the quotient. Print the answer in int main(void)
• Call a UDF to find the remainder. Print the answer in int main(void)

pseudocode
UDF for quotient:
double quotient(int x, int y)
{
    return x / y ---> With double cast on x to get more accurate division
}
UDF for remainder:
int remainder(int x, int y)
{
    return x % y
}
main()
{
    declare variables
    
    print(enter two numbers (x,y) to calculate x divided by y)
    scan for input
    
    call for UDFs
        quotient(x,y)
        remainder(x,y)
        
    print quotient and remainder
   
    return 0
}
*/
#include <stdio.h>

double quotient(int x, int y) // UDF for quotient
{
    return (double)x / y; // casting x as a double to get more accurate division for division whose remainder != 0
}

int remainder_(int x, int y) // had to put an underscore bc it looks like remainder is already a something else
{
    return x % y; // UDF for remainder.
}

int main()
{
    int x, y, rem;
    double qtnt; // declaring variables
    
    printf("enter two numbers (x,y) to calculate x divided by y: ");
    scanf("%d %d", &x, &y); // prompts user for input
    
    qtnt = quotient(x, y); // calls to my UDFs
    rem = remainder_(x , y);
    
    printf("%d divided by %d is %.4lf\n", x, y, qtnt);   // final output
    printf("The remainder of this division is %d", rem); // this feels a little clunky because since I got an exact quotient,
                                                         // there shouldn't be a remainder, so I may have been a little too
                                                         // compliant with the quotient function

    return 0;
}
