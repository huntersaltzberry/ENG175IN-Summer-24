/*
Ask the user for the number of elements to be stored in an array of type double. Use dynamic allocation to
store the amount of memory required based on the user input. Each element of the array represents a
temperature measurement. Using a while loop to initialize each element of the allocated memory to a
value between 0 – 120.
Create a user defined function (UDF) which is passed the pointer variable to the dynamica allocated
memory. Indie the UDF print the maximum temperature value, the avg temperature, and minimum
temperature.

Test Data:
Input: size =5
Array: [1,2,3,4,5]
Output:
The maximum temperature is 5 fahrenheit
The minimum temperature is 1 fahrenheit
The average temperature is 3 fahrenheit

pseudocode:
This one is a little harder so I'll go step by step

UDF
void tempInfo(double array[], int size) --> void bc returning print
{
    find max temp
    double max = array[0]
    for (int i = 0; i < size; i++){
        if (array[i] > max){
            max = array[i]
        }
    }
    
    find min temp
    double min = array[0]
    for (int i = 0; i < size; i++){
        if (array[i] < min){
            min = array[i]
        }
    }
    
    find average
    double sum = 0
    for (int i = 0, i < size, i++){
        sum += array[i]
    }
    double avg = sum / size
    
    ***I can actually combine these loops, so that's what I'll do in the actual code***
    
    printf("The maximum temperature is %.2lf fahrenheit.\n", max)
    printf("The minimum temperature is %.2lf fahrenheit.\n", min)
    printf("The average temperature is %.2lf fahrenheit.\n", avg)
}

main
{
    int size
    double *array --> using pointer to allocate memory instead of fixed size
    
    prompt user for size of array
    printf("Enter the size of the array: ")
    scanf("%d" &size)
    
    array = (double *)malloc(size * sizeof(double))
        I'm going to over-explain this to make sure I get it
        malloc requests a certain amount of memory and we need "size" number of cells
        each cell needs to be able to hold enough info to store doubles
        this whole chunk of memory is going to be assigned to "array"
        (double *) just says what kind of information we will be putting in each cell
        
    if (array = NULL){
        printf("Memory allocation failed")
        return 1
    }   this essentially means that the computer couldn't give the memory that was asked for
        so instead array points to nothing: NULL. We're returning 1 because something went wrong
    
    input array elements
    we can use a do/while loop to ensure that the inputs are between 1 and 120
    double temp
    for (i = 0; i < size; i++){
        do {
            printf("Enter Temperature #%d (Value must be between 1 and 120 inclusive)", i + 1)
            scanf("%lf", &temp)
            if (temp < 1 || temp > 120) {
                printf("Invalid temperature. Please enter a value between 1 and 120.\n")
            }
        } while (temp < 1 || temp > 120) --> stays in loop if invalid temp
        array[i] = temp
    }
    
    UDF goes here, gonna work on it now
    call UDF
    tempInfo(array, size)
    
    Free the allocated memory
    free(array)
    
    return 0
}


*/

#include <stdio.h>
#include <stdlib.h> // for malloc and free

void tempInfo(double array[], int size) // UDF for the info on the temps
{
    double max = array[0]; // declaring variables
    double min = array[0];
    double sum = 0;
    
    for (int i = 0; i < size; i++){ // for loop to go through all elements to find the info
        if (array[i] > max){ // compares elements to find max
            max = array[i];
        }
        if (array[i] < min){ // compares elements to find min
            min = array[i];
        }
        sum += array[i]; // calculates the sum of all elements
    }
    
    double avg = sum / size; // uses sum of elements to calculate average
    
    printf("The maximum temperature is %.2lf fahrenheit.\n", max);
    printf("The minimum temperature is %.2lf fahrenheit.\n", min);
    printf("The average temperature is %.2lf fahrenheit.\n", avg);
}

int main()
{
    int size; // declaring variables
    double *array;
    
    printf("Enter the size of the array: "); // prompts user for number of temps
    scanf("%d", &size);
    
    array = (double *)malloc(size * sizeof(double)); // sets up dynamic allocation
    
    if (array == NULL){ // used to abort program if allocation fails
        printf("Memory allocation failed");
        return 1;
    }
    
    double temp;
    for (int i = 0; i < size; i++){ // loop to enter temps
        do { // do/while to ensure valid input
            printf("Enter Temperature #%d (Value must be between 1 and 120 inclusive): ", i + 1); // prompts user for temps
            scanf("%lf", &temp);
            if (temp < 1 || temp > 120){ // ensures valid input
                printf("Invalid temperature. Please enter a value between 1 and 120.\n");
            }
        } while (temp < 1 || temp > 120);
        array[i] = temp;
    }

    tempInfo(array, size); // calls UDF
    
    free(array); // frees allocated memory (always used with allocation functions)
    
    return 0;
}