// pseudocode
// declare variables
    // char operation
    // double num1, num2, result
    // char continue
// prompt user for operation
// scanf for operation
// prompt user for two numbers
// scanf for two numbers
// switch cases
    // addition
    // subtraction
    // multiplication
    // division
// prompt user if they want to continue
    
#include <stdio.h>

int main()
{
    char operation;
    double num1, num2, result;
    char cont = 'y';
    
    while (cont == 'y' || cont == 'Y'){    // keeps the calculator 'on' as long as continue value is set to 'yes'
        printf("Choose an operation (+, -, x, /): "); // prompts user for an operation
        scanf(" %c", &operation);
    
        if (operation != '+' && operation != '-' && operation != 'x' && operation != '/'){
            printf("Invalid input. Input one of the following operators: +, -, x, /\n"); // checks for invalid operator
            continue; // breaks while loop if invalid operator is selected
        }
    
        printf("Input two numbers: "); // print and scan statements that take the two numbers
        scanf("%lf %lf", &num1, &num2 );
        
        switch(operation){
            case '+': // addition
                result = num1 + num2;
                printf("%lf + %lf = %lf\n", num1, num2, result);
                break; // breaks the while loop (same comments for other three cases)
            case '-':
                result = num1 - num2;
                printf("%lf - %lf = %lf\n", num1, num2, result);
                break;
            case 'x':
                result = num1 * num2;
                printf("%lf x %lf = %lf\n", num1, num2, result); // it might have been less confusing to use * instead of x
                break;
            case '/':
                if (num2 == 0){
                 printf("Undefined value: You can't divide by zero.\n"); // since you can't divide by zero, I added a comment
                 break;
                }
                else{
                    result = num1 / num2;
                    printf("%lf / %lf = %lf\n", num1, num2, result);
                    break;
                }
        }
        
        printf("Would you like to perform another calculation? (y/n): \n"); // gives user a chance to say no to continuing
        scanf(" %c", &cont); // which will break the while loop and end the program
    }
        
    return 0;
}
