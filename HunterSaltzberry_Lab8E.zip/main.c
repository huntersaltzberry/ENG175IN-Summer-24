/*
Write a program that passes an array to a UDF. The UDF then sum the elements of the array and the
result is then printed in the main program.
Test case:
23.4, 55, 22.6, 3, 40.5, 18

pseudocode:

UDF for sum:
double total(double arr[], size)
{
    double sum = 0

    for (int i = 0, i < size, i++){
        sum += array[i]
    }
    
    return sum
}

Main function:
int main()
{
    int size, sum
    
    get size of array:
    print("Enter the size of the array: ")
    scanf("%d", &size)
    
    double array[size]
    
    prompt user to enter elements with for loop:
    for (int i = 0; i < size; i++){
        printf("Enter array element #%d", i + 1)
        scanf("%d", &array[i])
    }
    
    for loop for final print statement:
    for (i = 0; i < size - 1; i++){
        printf("%lf + ", array[i]) --> going to do the same thing as last lab where I print the last element alone
    }
    printf("%lf", array[size])
    
    sum = total(array, size)
    
    printf("= %d", sum)
    
    return 0
}
*/

#include <stdio.h>

double total(double arr[], int size) // UDF to get sum of array elements
{
    double sum = 0;

    for (int i = 0; i < size; i++){ // for loop that will calculate the sum
        sum += arr[i];
    }
    
    return sum; // returns sum so it can used in main
}

int main()
{
    int size; // declaring variables
    double sum;
    
    printf("Enter the size of the array: "); // prompts user for size of array
    scanf("%d", &size);
    
    double array[size]; // uses given size to declare array

    for (int i = 0; i < size; i++){ // prompts the user for array elements
        printf("Enter array element #%d: ", i + 1);
        scanf("%lf", &array[i]);
    }
    
    for (int i = 0; i < size - 1; i++){ // for loop to print out addends for final print statement
        printf("%.2lf + ", array[i]);
    }
    printf("%.2lf ", array[size - 1]); // printing last element outside of loop so it doesn't have a '+'
    
    sum = total(array, size); // calls UDF to get the sum of array elements
    
    printf("= %.2lf", sum); // prints the sum
    
    return 0;
}
