// pseudocode

// this one seems to be pretty simple
// bool adult, int age
// prompt user for age
// if age >= 18 then adultbool is true
// if else print statements


#include <stdio.h>
#include <stdbool.h>


int main()
{
    bool adult = false; // initializing my boolean and age variables
    int age;
    
    printf("How old are you?: "); // prompts user for info
    scanf("%d", &age);
    
    if (age >= 18){ // sets the adult boolean
        adult = true;
    }
    
    if (adult == true){ // print statements for both cases
        printf("You're an adult. You are %d years old", age);
    }
    else{
        printf("You're not an adult. You are %d years old", age);
    }

    return 0;
}
