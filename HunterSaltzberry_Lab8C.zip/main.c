/*
Write a C program to
• Print a menu for users to select an option
• Create one UDF for cuboid calculations. Print in int main(void)
• Create one UDF for cylinder calculations. Print in UDF
• Create one UDF for hemisphere calculations. Print in int main(void)
**SURFACE AREA**

pseudocode:
UDFs:
double cuboid(double x, double y, double z) ---> using doubles here in case user would like to use more precise numbers
{
    return (2 * x * y) + (2 * y * z) + (2 * z * x)
}
void cylinder(double radius, double h) --> using void bc we're printing in UDF so no return needed
{
    printf("The surface area of the cylinder is %.4lf", (2 * m_pi * radius) * (radius + h))
}
void hemisphere(double radius, double *h_area, double h_volume) --> returning two values? maybe use pointers??
                                             --> using void since we aren't returning anything since using pointers
{
    *h_area = 2 * m_pi * radius * radius
    *h_volume = (2.0 / 3.0) * m_pi * radius * radius * radius
}
main()
{
    double x, y, z, height, radius, area, vol, h_area, h_volume
    int choice
    int valid_choice = 0
    
    *menu* --> using switch
    use a do/while loop to ensure that code doesn't end if invalid choice is picked
    
    do{
        printf("***Welcome to the Surface Area Calculator!***\n")
        printf("Select 1 for a cuboid, 2 for a cylinder, and 3 for a hemisphere!\n")
        printf("Enter 4 to exit the program!")
        scanf("%d", &choice)
        switch(choice)
            case 1:
                printf("Enter the length, width, and height of the cuboid!")
                scanf("%lf %lf %lf", &x, &y, &z)
                area = cuboid(x, y, z)
                printf("The surface area of the cuboid is %.2lf", area)
                valid_choice = 1
                break
            case 2:
                printf("Enter the height then the radius of the cylinder!")
                scanf("%lf %lf", height, radius)
                cylinder(height, radius)
                valid_choice = 1
                break
            case 3:
                printf("Enter the radius of the hemisphere!")
                scanf("%lf", radius)
                hemisphere(radius, &h_area, &h_volume)
                printf("The surface area of the hemisphere is %.4lf and the volume is %.4lf!", h_area, h_volume)
                valid_choice = 1
                break
            case 4:
                printf("Exiting the program!")
                valid_choice = 1
                break
            default:
                printf("Please enter a valid choice!\\n")
    } while (valid_choice != 1)
    
}

Add try again loops
*/

#include <stdio.h>
#include <math.h> // for pi

double cuboid(double x, double y, double z) // UDF for cuboid, simple and self explanatory
{
    return (2 * x * y) + (2 * y * z) + (2 * z * x);
}

void cylinder(double radius, double h) // UDF for cylinder. we use void because we are reurning a print statement, not values
{
    printf("\nThe surface area of the cylinder is %.4lf\n", (2 * M_PI * radius) * (radius + h));
}

void hemisphere(double radius, double *h_area, double *h_volume) // UDF for hemisphere
{                                                               // using pointers so that I can return both values
                                                    // since there are no values that are technically returned by the function, we use void
    *h_area = 2 * M_PI * radius * radius;
    *h_volume = (2.0 / 3.0) * M_PI * radius * radius * radius;
}

int main() // main function
{
    double x, y, z, height, radius, area, vol, h_area, h_volume; // decalring my variables
    int choice;
    int valid_choice = 0; // variable to use the try-again loop
    
    do{ 
        printf("\n***Welcome to the Surface Area Calculator!***\n"); // menu to select shape
        printf("Select 1 for a cuboid, 2 for a cylinder, and 3 for a hemisphere!\n");
        printf("Enter 4 to exit the program! ");
        scanf("%d", &choice); // prompts user for input
        
        switch(choice){
            case 1: // cuboid case
                printf("Enter the length, width, and height of the cuboid! ");
                scanf("%lf %lf %lf", &x, &y, &z);
                area = cuboid(x, y, z); // calls UDF
                printf("\nThe surface area of the cuboid is %.2lf\n", area);
                printf("Enter 0 if you'd like to try again and 1 if you'd like to exit! "); // prompts for try-again
                scanf("%d", &valid_choice);
                break;
            case 2: // cylinder case
                printf("Enter the height then the radius of the cylinder! ");
                scanf("%lf %lf", &height, &radius);
                cylinder(height, radius); // calls UDF, and it already makes the print statement
                printf("Enter 0 if you'd like to try again and 1 if you'd like to exit! "); // prompts for try-again
                scanf("%d", &valid_choice);
                break;
            case 3: // hemisphere case
                printf("Enter the radius of the hemisphere! ");
                scanf("%lf", &radius);
                hemisphere(radius, &h_area, &h_volume); // calls UDF using pointer addresses to get 2 values
                printf("\nThe surface area of the hemisphere is %.4lf and the volume is %.4lf!\n", h_area, h_volume);
                printf("Enter 0 if you'd like to try again and 1 if you'd like to exit! "); // prompts for try-again
                scanf("%d", &valid_choice);
                break;
            case 4: // case that lets you exit the loop
                valid_choice = 1;
                break;
            default: // loops if invalid choice is picked
                printf("Please enter a valid choice!\n\n");
        }
    } while (valid_choice != 1); // do while loop to allow user to try again
    
    printf("\nExiting the program!"); // exit message
    
    return 0;
}
