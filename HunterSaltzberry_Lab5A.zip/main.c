/*
Write a program that reads a list of integers and outputs them in reverse. Have the user input 5 numbers
from the screen, then print the integers in reverse.

pseudocode:
int array[5]

for loop to enter array elements
    printf(enter element %d, i+1)
    scanf(%d, &array[i])

for loop that starts at i=4 and decrements to i=0
    printf(element i of array)
*/
#include <stdio.h>

int main()
{
    int array[5]; // initializes my array
    
    for (int i = 0; i <= 4; i++){ // for loop to prompt user for array
        printf("enter element %d: ", i+1);
        scanf("%d", &array[i]); // scans each number of array until it reaches element 4 (the fifth element)
    }
    
    for (int i = 4; i >= 0; i--){
        printf("%d ", array[i]); // for loop that prints the fifth element and then decrements, printing each element in reverse
    }

    return 0;
}
