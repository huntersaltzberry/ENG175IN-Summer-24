// pseudocode

// I learned about the ctype library in an earlier lab so this one should be pretty simple

// include ctype.h
// char c
// prompt user for input
// use if/else branches that say if the character is a letter or number
    // isalpha and isdigit
    // (There is another one called isalnum which checks for alphanumeric characters but its not neccessary here)

#include <stdio.h>
#include <ctype.h> // including ctype library so I don't have to use 'c' >= A && <= Z, etc.

int main()
{
    char c; // declare variable
    
    printf("Input any character: "); // prompts user for character
    scanf("%c", &c); // I couldn't include a space before %c and even after doing research I'n still confused as to when and when not to do that

    if (isalpha(c)){ // case for if character is a letter
        printf("Your character is a letter.");
    }
    else if (isdigit(c)){ // case for if character is a number
        printf("Your character is a number.");
    }
    else{ // case for neither
        printf("Your character is not a letter or a number.");
    }
    
    return 0;
}
