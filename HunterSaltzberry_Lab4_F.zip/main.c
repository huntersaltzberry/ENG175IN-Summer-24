// pseudocode

// i need to write this before i forget my thought process
// we use 10^x -1 to get each subsequent number

// include math.h for pow function
// int x, sum = 0
// prompt user for number
// if loop for if zero is entered (because it would result in 1)
    // loop checks for x < 1
// else do the code --> gonna do it the other way around
// while (x >= 1)
    // sum += pow(10, x) - 1
    // x--
//print sum

#include <stdio.h>
#include <math.h> // including math.h for pow function

int main()
{
    int x; // initiazles variables
    int sum = 0;
    
    printf("Enter a number to get your sum: "); // prompts user for number
    scanf("%d", &x);
    
    if (x >= 1){ // checks if a valid number greater than 0 is inputted
        while (x >= 1){
        sum += pow(10, x) - 1; // sumnation equation tht fits the prompt
        x--; // reduces x
        }
    printf("Your sum is %d", sum); // prints the sum
    }
    else{ // else statement for invalid input
        printf("no output");
    }

    return 0;
}
