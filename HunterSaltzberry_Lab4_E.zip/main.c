// pseudocode

// I did a similar lab when I took part of a C class before
// I had to use a nested for loop to make a triangle, so this may be similar

// int x, i, j (i for rows and j for columns [or maybe the other way around])
// prompt user for x

// for i up to x
    // for j up to x
        // print "#"
    // print new line (to make a new row)
#include <stdio.h>

int main()
{
    int x, i, j; // initializing variables
    
    printf("What size do you want your square to be?: "); // prompts user for input
    scanf("%d", &x);
    
    for (i = 1; i <= x; i++){ // loop that creates each new row
        for (j = 1; j<= x; j++){ // loop that puts number of hashtags in each row
            printf("# ");
        }
        printf("\n"); // new line to go to the next row
    }

    return 0;
}
