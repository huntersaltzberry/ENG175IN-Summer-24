/*
Create a program to compute the sum of all elements in an array using pointers. Print the
address of each element in the array.
(Hint: User deference operator to access the value of the pointer variable)
Test Data:
Input = {1,2,3,4,5}
Output = the sum of the elements is 15

pseudocode

declare variables for array size, sum, the array itself, and the pointer
prompt user for array size
for loop to input each number into the array
    printf enter element
    scanf for element using ptr to get the address
for loop to calculate the sum and print the addresses
    printf the element, the value of the element, and its address
    sum += *(ptr + i) which will use the pointer to access the value
print the sum

*/
#include <stdio.h>

int main(){

    int size; // declaring variables
    int sum = 0;

    printf("Input the size of the array: "); // prompts user for size of array
    scanf("%d", &size);
    
    int array[size]; // declares an array of the given size
    int *ptr = array; // initializes pointer to the start of the array
    
    // my code wasn't working. I realized that I have to initialize these variables later because I need to define the size first

    for (int i = 0; i < size; i++) { // for loop to input elements of the array
        printf("Input element %d: ", i + 1); // prompts user for each element of the array
        scanf("%d", ptr + i); // we use ptr + i to get the address of each array element 
        // and scanf() stores the input at that address.
    }

    printf("\nElement values and addresses:\n");
    for (int i = 0; i < size; i++) { // for loop that will simultaneously calculate the sum and print the element addresses
        printf("For element %d, the value is %d, and the address is %p\n", i + 1, *(ptr + i), (void*)(ptr + i));
        // casting the pointer to (void*) when printing addresses to avoid warnings.
        // the reason that *(ptr + i) prints as an integer is because we dereference it
        // but (void*)(ptr + i) is not dereferenced so it prints the address

        // adding the value of the current element to sum
        sum += *(ptr + i);  // dereferencing the pointer so that we can access the value
    }

    printf("The sum of all of the elements is %d\n", sum); // prints the sum
    
    // very interesting lab. I learned a lot and became a lot more comfortable working with pointers

    return 0;
}