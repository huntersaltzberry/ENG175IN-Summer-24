// pseudocode
// include stdio and math libraries (math for pi)
// main function
    // define doubles for radius, diameter, circumference, and area
    // prompt user for radius with printf
    // scanf to get the input
    // perform calculations
        // diameter = 2 * radius
        // circumference = diameter * pi
        // area = pi * radius^2
    // print the area, circumference and diameter
    
#include <stdio.h>
#include <math.h>

int main()
{
    double radius, diameter, circumference, area; // defining our variables
    
    printf("Enter the radius of the circle: "); // prompts user to enter radius
    scanf("%lf", &radius); // allows user to input the radius
    
    diameter = radius * 2; // calculates diameter
    circumference = diameter * M_PI; //calculates circumference
    area = pow(radius, 2) * M_PI; // calculates area
    
    printf("\nMeasurements of the circle:\nDiameter: %.2lf\nCircumference: %.2lf\nArea: %.2lf", diameter, circumference, area);
    // final print statement

    return 0;
}
