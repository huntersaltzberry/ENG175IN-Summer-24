/*
Writing the prompt here so I don't need to keep going back to look

Write a code using a while loop to determine if a number is a perfect number. A perfect number is a
number equal to the sum of its positive divisors excluding the number itself. Ask the user if they want to
try another number.
*/

// pseudocode

// int number, candidate, i
// prompt user for number
// while loop
// while (i < number)
    // if number % i == 0
        // candidate += i
    // i++
// if candidate == number
    // print success statement
// else print fail statement

// put it all in a while statement so that code can be ran again

#include <stdio.h>

int main()
{
    while(1){ // while loop so user can try again
        
        int number, cont; // initializing my variables
        int i = 1;
        int candidate = 0;
        

        printf("Pick a number to see if it's a perfect number: "); // prompts user for input
        scanf("%d", &number);
            
        if (number > 0){ // checks if you put in 0 or less
            while (i < number){
                if (number % i == 0){ // checks if i is a factor of the number then adds it if it is
                    candidate += i;
                }
                i++; // increments i to check all factors
            }
            
            if (candidate == number){ // perfect number statement
                printf("Wow! %d is a perfect number!\n", number);
            }
            else{ // non perfect number statement
                printf("Sorry, %d is not a perfect number.\n", number);
            }
        }
        else{ // prints if invalid number is entered
            printf("Pick a non-zero postive integer\n");
        }
        
        printf("If you want to try again, input '1', otherwise, input something else.\n"); 
        scanf("%d", &cont);
        if (cont != 1){ // try again statements
            break;
        }
    }

    return 0;
}
