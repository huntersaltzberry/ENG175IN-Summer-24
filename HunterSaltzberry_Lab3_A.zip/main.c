// pseudocode

// define int number
// prompt for input
// scan for input
// if else statements to determine if number is even (using divisibility)
// make two separate print statements

#include <stdio.h>

int main()
{
    int number; // initialize number variable
    
    printf("Enter a number: "); // prompts user for number
    scanf("%d", &number); // takes input for number
    
    if (number % 2 == 0){      // determines if number is divisible by 2 (definition of an even number)
        printf("Your number is even"); // final print statement 1   
    }
    else{ // if not divisible then number is odd
            printf("Your number is odd"); // final print statement 2 
    }
        

    return 0;
}
