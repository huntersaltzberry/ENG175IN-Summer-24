/*
Write a code to calculate the length of a string using pointers. Do not include null terminator in the
sum.
(Hint: the null terminator string (%) will be NULL)
Test case1:
Input: “Engineering”
Output: The size of the string is 11
Test case2:
Input: “Hello world!”
Output: The sum is 12

***pseudocode***

declare my variables
prompt user for the string
set the pointer to point to the first character of the string
while loop to keep incrementing the pointer until we hit null terminator (\0)
    length++
    pointer++ to move the pointer to the next character
print statement that displays the length of the string

I was getting incorrect results and upon some research it looks like fgets reads the new line when
I press enter. So I did some research on how to remove the new line, and I will implement this 
before the while loop.

*/
#include <stdio.h>
#include <string.h>

int main()
{
    char input[100];  // declaring my string, pointer, and length
    char *ptr;
    int length = 0;

    printf("Enter a string: ");
    fgets(input, sizeof(input), stdin); // prompts user for input
    // we use fgets for strings instead of scanf for a few reasons, mostly consistency
    
    // removing the new line
    input[strcspn(input, "\n")] = '\0'; // basically, this replaces the new line with a null terminator so that it isn't counted
    
    ptr = input;  // initializing ptr to point to the first character of input
    while (*ptr != '\0') {  // continues the loop until null terminator is found
        length++; // increments length for each character
        ptr++; // moves pointer to next character
        }
        
    printf("The size of the string is %d\n", length); // final print statement

    return 0;
}
