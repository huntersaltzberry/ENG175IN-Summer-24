// pseudocode

// not super necessary because the project has a step by step guide on what to do
// basically just follow the project
// declare variables, do math, and make the proper print statements
// no user input required

#include <stdio.h>

int main() {

    double sample = 7.734; // declaring all of my variables
    double s0 = 3.47;
    double s1 = 10.00;
    double t0 = 28.6000;
    double t1 = 21.1854; // picked these values from the adjacent rows of my sample
    double TpredictionF, TpredictionC, ppt;

    TpredictionF = t0 + ((t1 - t0) * ((sample - s0) / (s1 - s0))); // using my variables, not hard-coding
    
    printf("The predicted freezing temperature of water with a salinity\nof %lf percent is %lf degrees Fahrenheit.\n", sample, TpredictionF);
    // my first print statement
    
    printf("\nThe predicted freezing temperature of water with a salinity\nof %.2lf percent is %.4lf degrees Fahrenheit.\n", sample, TpredictionF);
    // second print statement with correct sigfigs
    
    TpredictionC = (TpredictionF - 32) * (5.0 / 9.0); // converting temp to Celsius
    // I actually did 5/9 at first and didnt realize that I had to use floats to keep my answer as a double, very interesting

    ppt = sample * 10; // calculating ppt from percentage
    
    printf("\nThe predicted freezing temperature of water with a salinity\nof %.2lf ppt is %.4lf degrees Celsius.", ppt, TpredictionC);
    // print statement for Celsius
    
    // I think this is all

    return 0;
}